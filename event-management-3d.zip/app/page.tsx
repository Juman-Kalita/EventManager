"use client"

import { useRef } from "react"
import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { EventsSection } from "@/components/events-section"
import { StatsSection } from "@/components/stats-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { GallerySection } from "@/components/gallery-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { AboutSection } from "@/components/about-section"
import { VenuesSection } from "@/components/venues-section"
import { VenueExplorationSection } from "@/components/venue-exploration-section"
import { WhatsAppButton } from "@/components/whatsapp-button"

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null)

  return (
    <main className="relative">
      <Navbar />
      <Hero />
      <AboutSection />
      <EventsSection />
      <VenuesSection />
      <VenueExplorationSection />
      <StatsSection />
      <TestimonialsSection />
      <GallerySection />
      <ContactSection />
      <Footer />
      <WhatsAppButton
        phoneNumber="+919876543210"
        message="Hello! I'm interested in your event management services in Delhi."
        variant="floating"
      />
    </main>
  )
}
