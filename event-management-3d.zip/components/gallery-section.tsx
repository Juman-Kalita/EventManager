"use client"

import { motion } from "framer-motion"
import { useState, useRef } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

const galleryImages = [
  {
    src: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?q=80&w=2069&auto=format&fit=crop",
    alt: "Corporate networking event with professionals mingling",
  },
  {
    src: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?q=80&w=2070&auto=format&fit=crop",
    alt: "Elegant wedding reception with beautiful decorations",
  },
  {
    src: "https://images.unsplash.com/photo-1496337589254-7e19d01cec44?q=80&w=2070&auto=format&fit=crop",
    alt: "Birthday celebration with colorful decorations",
  },
  {
    src: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=2070&auto=format&fit=crop",
    alt: "Music concert with enthusiastic audience",
  },
  {
    src: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?q=80&w=2070&auto=format&fit=crop",
    alt: "Graduation celebration with caps and gowns",
  },
  {
    src: "https://images.unsplash.com/photo-1555244162-803834f70033?q=80&w=2070&auto=format&fit=crop",
    alt: "Formal gala dinner with elegant table settings",
  },
  {
    src: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?q=80&w=2070&auto=format&fit=crop",
    alt: "Team building activity outdoors",
  },
  {
    src: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=2012&auto=format&fit=crop",
    alt: "Product launch event with modern stage setup",
  },
]

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const constraintsRef = useRef(null)

  const [filter, setFilter] = useState<string>("all")
  const [isDownloading, setIsDownloading] = useState<string | null>(null)

  const categories = ["all", "corporate", "wedding", "birthday", "concert", "graduation", "gala"]

  const categorizedImages = galleryImages.map((image, index) => ({
    ...image,
    category: categories[Math.floor(index / 2) + 1] || "corporate",
  }))

  const filteredImages =
    filter === "all" ? categorizedImages : categorizedImages.filter((image) => image.category === filter)

  const handleDownload = async (imageUrl: string, imageName: string) => {
    setIsDownloading(imageUrl)
    try {
      const response = await fetch(imageUrl)
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `stellar-events-${imageName}.jpg`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Download failed:", error)
    } finally {
      setIsDownloading(null)
    }
  }

  return (
    <section id="gallery" className="scroll-section py-24">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Event Gallery</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-xl">
              Browse through our portfolio of successful events and get inspired.
            </p>
          </motion.div>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category}
                variant={filter === category ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter(category)}
                className="capitalize"
              >
                {category === "all" ? "All Events" : category.replace(/([A-Z])/g, " $1").trim()}
              </Button>
            ))}
          </div>

          <motion.div
            ref={constraintsRef}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-8"
          >
            {filteredImages.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                whileHover={{
                  scale: 1.05,
                  rotateY: 5,
                  rotateX: 5,
                  z: 50,
                }}
                className="relative group cursor-pointer overflow-hidden rounded-lg image-3d"
              >
                <img
                  src={image.src || "/placeholder.svg"}
                  alt={image.alt}
                  className="w-full h-64 object-cover"
                  onClick={() => setSelectedImage(image.src)}
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={(e) => {
                      e.stopPropagation()
                      setSelectedImage(image.src)
                    }}
                  >
                    View
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleDownload(image.src, `image-${index}`)
                    }}
                    disabled={isDownloading === image.src}
                  >
                    {isDownloading === image.src ? "Downloading..." : "Download"}
                  </Button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          {selectedImage && (
            <img src={selectedImage || "/placeholder.svg"} alt="Gallery image" className="w-full h-auto" />
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
