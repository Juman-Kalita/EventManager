"use client"

import type React from "react"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Instagram, Twitter, Linkedin, ArrowRight, MessageCircle, Phone } from "lucide-react"
import { WhatsAppButton } from "@/components/whatsapp-button"
import { Logo } from "@/components/logo"
import { VisitorCounter } from "@/components/visitor-counter"
import { VisitorAnalytics } from "@/components/visitor-analytics"

export function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  const handleSocialClick = (platform: string) => {
    const socialLinks = {
      facebook: "https://facebook.com/stellarevents",
      instagram: "https://instagram.com/stellarevents",
      twitter: "https://twitter.com/stellarevents",
      linkedin: "https://linkedin.com/company/stellarevents",
      whatsapp: "https://wa.me/919876543210",
    }
    window.open(socialLinks[platform as keyof typeof socialLinks], "_blank")
  }

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const email = (form.elements.namedItem("email") as HTMLInputElement).value

    if (email) {
      // Simulate newsletter subscription
      alert("Thank you for subscribing to our newsletter!")
      form.reset()
    }
  }

  return (
    <>
      {/* Visitor Counter Section */}
      <VisitorCounter />
      <VisitorAnalytics />

      {/* Main Footer */}
      <footer className="bg-background border-t">
        <div className="container px-4 md:px-6 py-12 md:py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <Link href="/" className="flex items-center">
                <Logo size="lg" />
              </Link>
              <p className="text-sm text-muted-foreground">
                Transforming your vision into extraordinary experiences. Your premier event management partner in Delhi.
              </p>
              <div className="flex space-x-4">
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full"
                  onClick={() => handleSocialClick("facebook")}
                >
                  <Facebook className="h-5 w-5" />
                  <span className="sr-only">Facebook</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full"
                  onClick={() => handleSocialClick("instagram")}
                >
                  <Instagram className="h-5 w-5" />
                  <span className="sr-only">Instagram</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full"
                  onClick={() => handleSocialClick("twitter")}
                >
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full"
                  onClick={() => handleSocialClick("linkedin")}
                >
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full bg-green-100 text-green-600 hover:bg-green-200 hover:text-green-700"
                  onClick={() => handleSocialClick("whatsapp")}
                >
                  <MessageCircle className="h-5 w-5" />
                  <span className="sr-only">WhatsApp</span>
                </Button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => scrollToSection("hero")}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Home
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("about")}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    About Us
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("services")}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Services
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("venues")}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Venues
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("gallery")}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Gallery
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Contact
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Corporate Events
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Weddings
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Birthday Celebrations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Concerts & Music Festivals
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Graduation Parties
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Gala Dinners
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <ul className="space-y-2 mb-4">
                <li className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <a
                    href="tel:+919876543210"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    +91 98765 43210
                  </a>
                </li>
                <li>
                  <WhatsAppButton phoneNumber="+919876543210" variant="outline" size="sm" className="mt-2 w-full" />
                </li>
              </ul>

              <h3 className="text-lg font-semibold mb-4">Subscribe</h3>
              <form onSubmit={handleNewsletterSubmit} className="flex space-x-2">
                <Input name="email" type="email" placeholder="Your email" className="max-w-[220px]" required />
                <Button type="submit" size="icon">
                  <ArrowRight className="h-4 w-4" />
                  <span className="sr-only">Subscribe</span>
                </Button>
              </form>
            </div>
          </div>

          <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Stellar Events. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}
