"use client"

import { motion, useAnimation } from "framer-motion"
import { useEffect } from "react"
import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Briefcase, Music, GraduationCap, Heart, Utensils } from "lucide-react"
import { Button } from "@/components/ui/button"

const events = [
  {
    title: "Corporate Events",
    description: "Conferences, product launches, team building, and corporate galas designed to impress.",
    icon: Briefcase,
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop",
  },
  {
    title: "Weddings",
    description: "Elegant ceremonies and receptions tailored to your unique love story.",
    icon: Heart,
    image: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=2070&auto=format&fit=crop",
  },
  {
    title: "Birthday Celebrations",
    description: "Milestone birthdays, surprise parties, and themed celebrations for all ages.",
    icon: Calendar,
    image: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?q=80&w=2070&auto=format&fit=crop",
  },
  {
    title: "Concerts & Music Festivals",
    description: "From intimate performances to large-scale music festivals with top-tier production.",
    icon: Music,
    image: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?q=80&w=2070&auto=format&fit=crop",
  },
  {
    title: "Graduation Parties",
    description: "Celebrate academic achievements with memorable graduation events.",
    icon: GraduationCap,
    image: "https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?q=80&w=2070&auto=format&fit=crop",
  },
  {
    title: "Gala Dinners",
    description: "Sophisticated dining experiences for fundraisers, awards, and special occasions.",
    icon: Utensils,
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=2070&auto=format&fit=crop",
  },
]

export function EventsSection() {
  const controls = useAnimation()
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  useEffect(() => {
    if (inView) {
      controls.start("visible")
    }
  }, [controls, inView])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  const handleLearnMore = (eventType: string) => {
    const element = document.getElementById("contact")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setTimeout(() => {
        const eventTypeField = document.querySelector('select[name="eventType"]') as HTMLSelectElement
        const messageField = document.querySelector('textarea[name="message"]') as HTMLTextAreaElement
        if (eventTypeField && messageField) {
          // Set the event type based on the card clicked
          const eventTypeMap: { [key: string]: string } = {
            "Corporate Events": "corporate",
            Weddings: "wedding",
            "Birthday Celebrations": "birthday",
            "Concerts & Music Festivals": "concert",
            "Graduation Parties": "graduation",
            "Gala Dinners": "gala",
          }
          eventTypeField.value = eventTypeMap[eventType] || "other"
          messageField.value = `I'm interested in planning a ${eventType.toLowerCase()} event.`
        }
      }, 500)
    }
  }

  return (
    <section id="services" className="scroll-section py-24 bg-gradient-to-b from-background to-secondary/20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Event Services</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-xl">
              We specialize in a wide range of events, each crafted with precision and creativity.
            </p>
          </motion.div>

          <motion.div
            ref={ref}
            variants={containerVariants}
            initial="hidden"
            animate={controls}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8"
          >
            {events.map((event, index) => (
              <motion.div key={index} variants={itemVariants} className="event-card">
                <Card className="overflow-hidden h-full tilt-effect">
                  <div className="aspect-video relative overflow-hidden parallax-image-container">
                    <img src={event.image || "/placeholder.svg"} alt={event.title} className="parallax-image" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                      <h3 className="text-xl font-bold text-white">{event.title}</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <event.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-muted-foreground mb-3">{event.description}</p>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full"
                          onClick={() => handleLearnMore(event.title)}
                        >
                          Learn More
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
