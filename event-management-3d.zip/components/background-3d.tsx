"use client"

import { useRef, useEffect } from "react"
import { useFrame, useThree } from "@react-three/fiber"
import { useScroll } from "@react-three/drei"
import * as THREE from "three"

export function Background3D() {
  const { viewport } = useThree()
  const scroll = useScroll()
  const particlesRef = useRef<THREE.Points>(null)
  const particlesGeometryRef = useRef<THREE.BufferGeometry>(null)

  // Create particles
  useEffect(() => {
    if (!particlesGeometryRef.current) return

    const particleCount = 2000
    const positions = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)

    const color = new THREE.Color()

    for (let i = 0; i < particleCount; i++) {
      // Position
      positions[i * 3] = (Math.random() - 0.5) * 10
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10 + 5 * (i / particleCount)
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10

      // Color
      const colorValue = Math.random()
      color.setHSL(0.6 - colorValue * 0.1, 0.7, 0.7)
      colors[i * 3] = color.r
      colors[i * 3 + 1] = color.g
      colors[i * 3 + 2] = color.b

      // Size
      sizes[i] = Math.random() * 0.1 + 0.05
    }

    particlesGeometryRef.current.setAttribute("position", new THREE.BufferAttribute(positions, 3))
    particlesGeometryRef.current.setAttribute("color", new THREE.BufferAttribute(colors, 3))
    particlesGeometryRef.current.setAttribute("size", new THREE.BufferAttribute(sizes, 1))
  }, [])

  // Animate particles
  useFrame((state, delta) => {
    if (!particlesRef.current || !particlesGeometryRef.current) return

    const positions = particlesGeometryRef.current.attributes.position.array as Float32Array
    const count = positions.length / 3

    for (let i = 0; i < count; i++) {
      const i3 = i * 3

      // Move particles based on scroll
      positions[i3 + 1] -= delta * 0.2

      // Reset particles that go out of view
      if (positions[i3 + 1] < -5) {
        positions[i3 + 1] = 5
      }
    }

    particlesGeometryRef.current.attributes.position.needsUpdate = true

    // Rotate the entire particle system
    particlesRef.current.rotation.y += delta * 0.05

    // Move based on scroll
    particlesRef.current.position.y = -scroll.offset * 10
  })

  return (
    <>
      <color attach="background" args={["#050816"]} />
      <ambientLight intensity={0.5} />
      <directionalLight position={[0, 10, 5]} intensity={1} />

      <points ref={particlesRef}>
        <bufferGeometry ref={particlesGeometryRef} />
        <pointsMaterial
          size={0.1}
          sizeAttenuation={true}
          vertexColors={true}
          transparent
          alphaTest={0.5}
          opacity={0.8}
        />
      </points>

      <mesh position={[0, 0, -5]} rotation={[0, 0, 0]}>
        <planeGeometry args={[50, 50]} />
        <meshBasicMaterial color="#090b1f" />
      </mesh>
    </>
  )
}
