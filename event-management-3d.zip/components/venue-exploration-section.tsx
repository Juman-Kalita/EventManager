"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { VenuesModal } from "@/components/venues-modal"

export function VenueExplorationSection() {
  const [isVenuesModalOpen, setIsVenuesModalOpen] = useState(false)

  return (
    <>
      <section className="py-24 bg-gradient-to-r from-gray-900 to-black text-white overflow-hidden">
        <div className="container px-4 md:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="space-y-4">
                <div className="aspect-square rounded-lg overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=400&auto=format&fit=crop"
                    alt="Elegant wedding venue"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?q=80&w=400&auto=format&fit=crop"
                    alt="Garden venue setup"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 mt-8">
                <div className="aspect-square rounded-lg overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1511578314322-379afb476865?q=80&w=400&auto=format&fit=crop"
                    alt="Corporate event venue"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=400&auto=format&fit=crop"
                    alt="Gala dinner venue"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
                  Struggling to find the perfect venue?
                </h2>
                <p className="text-xl text-gray-300 mb-2">Find your perfect venue hassle-free with Stellar Events.</p>
                <p className="text-lg text-gray-400">Easy booking, endless choices.</p>
              </div>

              <Button
                size="lg"
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-6 text-lg rounded-full"
                onClick={() => setIsVenuesModalOpen(true)}
              >
                Explore Venues
              </Button>

              <div className="absolute right-0 top-1/2 transform -translate-y-1/2 opacity-20 hidden xl:block">
                <svg width="200" height="300" viewBox="0 0 200 300" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M100 50C120 30 140 40 160 60C180 80 170 100 150 120C130 140 110 130 90 110C70 90 80 70 100 50Z"
                    fill="currentColor"
                  />
                  <path
                    d="M80 150C100 130 120 140 140 160C160 180 150 200 130 220C110 240 90 230 70 210C50 190 60 170 80 150Z"
                    fill="currentColor"
                  />
                </svg>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <VenuesModal isOpen={isVenuesModalOpen} onClose={() => setIsVenuesModalOpen(false)} />
    </>
  )
}
