"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, Users, Star, Phone } from "lucide-react"

const venues = [
  {
    name: "The Imperial Ballroom",
    location: "Connaught Place, Delhi",
    capacity: "500 guests",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=2098&auto=format&fit=crop",
    description: "Elegant ballroom perfect for weddings and corporate galas in the heart of Delhi.",
    features: ["Full catering kitchen", "Audio/Visual equipment", "Valet parking"],
  },
  {
    name: "Lotus Garden Resort",
    location: "Gurgaon, NCR",
    capacity: "300 guests",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?q=80&w=2069&auto=format&fit=crop",
    description: "Beautiful outdoor venue with lush gardens and modern amenities.",
    features: ["Outdoor ceremony space", "Weather contingency", "Garden setting"],
  },
  {
    name: "Delhi Convention Center",
    location: "Pragati Maidan, Delhi",
    capacity: "1000 guests",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1511578314322-379afb476865?q=80&w=2069&auto=format&fit=crop",
    description: "State-of-the-art facility for large corporate events and conferences.",
    features: ["High-tech AV systems", "Multiple halls", "Business center"],
  },
]

export function VenuesSection() {
  const handleBookVenue = (venueName: string) => {
    const element = document.getElementById("contact")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      // You could also pre-fill the form with venue information
      setTimeout(() => {
        const messageField = document.querySelector('textarea[name="message"]') as HTMLTextAreaElement
        if (messageField) {
          messageField.value = `I'm interested in booking ${venueName} for my event in Delhi.`
        }
      }, 500)
    }
  }

  const handleCallVenue = () => {
    window.open("tel:+919876543210", "_self")
  }

  return (
    <section id="venues" className="scroll-section py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Premium Venues in Delhi</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-xl">
              Choose from our carefully selected venues across Delhi NCR, each offering unique charm and exceptional
              service.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
            {venues.map((venue, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden h-full tilt-effect">
                  <div className="aspect-video relative overflow-hidden parallax-image-container">
                    <img src={venue.image || "/placeholder.svg"} alt={venue.name} className="parallax-image" />
                    <div className="absolute top-4 right-4 bg-white/90 rounded-full px-3 py-1 flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium">{venue.rating}</span>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-xl font-bold">{venue.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                          <MapPin className="h-4 w-4" />
                          {venue.location}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                          <Users className="h-4 w-4" />
                          Up to {venue.capacity}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{venue.description}</p>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        {venue.features.map((feature, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <div className="w-1 h-1 bg-primary rounded-full" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <div className="flex gap-2">
                        <Button size="sm" className="flex-1" onClick={() => handleBookVenue(venue.name)}>
                          Book Now
                        </Button>
                        <Button size="sm" variant="outline" onClick={handleCallVenue}>
                          <Phone className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
