"use client"

import type React from "react"

import { Dialog, DialogContent, DialogHeader } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useState } from "react"
import { X } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Logo } from "@/components/logo"

interface VenueBookingFormProps {
  isOpen: boolean
  onClose: () => void
  venue: {
    id: number
    name: string
    location: string
    price: string
  } | null
}

export function VenueBookingForm({ isOpen, onClose, venue }: VenueBookingFormProps) {
  const [formData, setFormData] = useState({
    fullName: "",
    phoneNumber: "",
    emailAddress: "",
    functionDate: "",
    numberOfGuests: "",
    numberOfRooms: "",
    functionType: "",
    functionTime: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    toast({
      title: "Booking Request Submitted!",
      description: `We'll contact you shortly regarding ${venue?.name} booking.`,
    })

    setIsSubmitting(false)
    onClose()

    // Reset form
    setFormData({
      fullName: "",
      phoneNumber: "",
      emailAddress: "",
      functionDate: "",
      numberOfGuests: "",
      numberOfRooms: "",
      functionType: "",
      functionTime: "",
    })
  }

  if (!venue) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <div>
            <div className="mb-4">
              <Logo size="md" />
            </div>
            <h2 className="text-2xl font-bold mt-2">Request Pricing</h2>
            <p className="text-sm text-muted-foreground mt-2">
              Fill this form and we will contact you shortly. All the information provided will be treated
              confidentially.
            </p>
            <div className="mt-4 p-3 bg-purple-50 rounded-lg">
              <p className="text-sm font-medium">Selected Venue: {venue.name}</p>
              <p className="text-xs text-muted-foreground">{venue.location}</p>
              <p className="text-sm font-bold text-purple-600">{venue.price}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">
                Full Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="fullName"
                placeholder="Full Name"
                value={formData.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phoneNumber">
                Phone number <span className="text-red-500">*</span>
              </Label>
              <Input
                id="phoneNumber"
                placeholder="Phone number"
                value={formData.phoneNumber}
                onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="emailAddress">Email address</Label>
              <Input
                id="emailAddress"
                type="email"
                placeholder="Email address"
                value={formData.emailAddress}
                onChange={(e) => handleInputChange("emailAddress", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="functionDate">
                Function date <span className="text-red-500">*</span>
              </Label>
              <Input
                id="functionDate"
                type="date"
                value={formData.functionDate}
                onChange={(e) => handleInputChange("functionDate", e.target.value)}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="numberOfGuests">Number of guests</Label>
              <Input
                id="numberOfGuests"
                placeholder="Number of guests"
                type="number"
                value={formData.numberOfGuests}
                onChange={(e) => handleInputChange("numberOfGuests", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="numberOfRooms">Number of rooms</Label>
              <Input
                id="numberOfRooms"
                placeholder="Number of rooms"
                type="number"
                value={formData.numberOfRooms}
                onChange={(e) => handleInputChange("numberOfRooms", e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <Label>
                Function Type <span className="text-red-500">*</span>
              </Label>
              <RadioGroup
                value={formData.functionType}
                onValueChange={(value) => handleInputChange("functionType", value)}
                required
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="wedding" id="wedding" />
                  <Label htmlFor="wedding">Wedding</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="other" id="other" />
                  <Label htmlFor="other">Other events</Label>
                </div>
              </RadioGroup>
            </div>
            <div className="space-y-3">
              <Label>
                Function Time <span className="text-red-500">*</span>
              </Label>
              <RadioGroup
                value={formData.functionTime}
                onValueChange={(value) => handleInputChange("functionTime", value)}
                required
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="day" id="day" />
                  <Label htmlFor="day">Day</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="evening" id="evening" />
                  <Label htmlFor="evening">Evening</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Submitting..." : "Check Availability & Prices"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
