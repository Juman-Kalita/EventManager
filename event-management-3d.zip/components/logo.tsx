"use client"

import { motion } from "framer-motion"

interface LogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function Logo({ className = "", size = "md" }: LogoProps) {
  const sizes = {
    sm: { container: "h-8", text: "text-lg", icon: "w-6 h-6" },
    md: { container: "h-10", text: "text-xl", icon: "w-8 h-8" },
    lg: { container: "h-12", text: "text-2xl", icon: "w-10 h-10" },
  }

  const currentSize = sizes[size]

  return (
    <motion.div
      className={`flex items-center gap-3 ${currentSize.container} ${className}`}
      whileHover={{ scale: 1.05 }}
      transition={{ type: "spring", stiffness: 400, damping: 10 }}
    >
      {/* Custom Logo Icon */}
      <div className={`${currentSize.icon} relative`}>
        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          {/* Outer ring with gradient */}
          <circle cx="20" cy="20" r="18" stroke="url(#gradient1)" strokeWidth="2" fill="none" />

          {/* Inner star/sparkle design */}
          <path d="M20 8L22.5 15H30L24.5 19.5L27 27L20 22L13 27L15.5 19.5L10 15H17.5L20 8Z" fill="url(#gradient2)" />

          {/* Small decorative dots */}
          <circle cx="32" cy="12" r="1.5" fill="url(#gradient1)" />
          <circle cx="8" cy="28" r="1.5" fill="url(#gradient1)" />
          <circle cx="32" cy="28" r="1" fill="url(#gradient2)" />
          <circle cx="8" cy="12" r="1" fill="url(#gradient2)" />

          {/* Gradient definitions */}
          <defs>
            <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="50%" stopColor="#A855F7" />
              <stop offset="100%" stopColor="#3B82F6" />
            </linearGradient>
            <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="50%" stopColor="#EF4444" />
              <stop offset="100%" stopColor="#8B5CF6" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Company Name with Custom Typography */}
      <div className="flex flex-col leading-none">
        <div
          className={`font-bold ${currentSize.text} bg-clip-text text-transparent bg-gradient-to-r from-purple-600 via-blue-600 to-purple-800`}
        >
          Stellar
        </div>
        <div className={`font-light text-sm text-gray-600 -mt-1 tracking-wider`}>EVENTS</div>
      </div>
    </motion.div>
  )
}
