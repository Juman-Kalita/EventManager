"use client"

import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"
import { motion } from "framer-motion"

interface WhatsAppButtonProps {
  phoneNumber: string
  message?: string
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "floating"
  size?: "default" | "sm" | "lg" | "icon"
  className?: string
}

export function WhatsAppButton({
  phoneNumber,
  message = "Hello! I'm interested in your event management services.",
  variant = "default",
  size = "default",
  className = "",
}: WhatsAppButtonProps) {
  // Format the phone number by removing any non-digit characters
  const formattedNumber = phoneNumber.replace(/\D/g, "")

  const handleWhatsAppClick = () => {
    // Create the WhatsApp URL with the phone number and optional message
    const whatsappUrl = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`
    // Open WhatsApp in a new tab
    window.open(whatsappUrl, "_blank")
  }

  if (variant === "floating") {
    return (
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
        className="fixed bottom-6 right-6 z-50"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          onClick={handleWhatsAppClick}
          size="icon"
          className="h-14 w-14 rounded-full bg-green-500 hover:bg-green-600 shadow-lg"
        >
          <MessageCircle className="h-7 w-7 text-white" />
          <span className="sr-only">Chat on WhatsApp</span>
        </Button>
      </motion.div>
    )
  }

  return (
    <Button
      onClick={handleWhatsAppClick}
      variant={variant === "floating" ? "default" : variant}
      size={size}
      className={`${className} ${variant === "default" ? "bg-green-500 hover:bg-green-600" : ""}`}
    >
      <MessageCircle className="mr-2 h-4 w-4" />
      Chat on WhatsApp
    </Button>
  )
}
