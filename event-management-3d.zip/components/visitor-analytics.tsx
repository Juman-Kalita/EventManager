"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, Smartphone, Monitor } from "lucide-react"

interface VisitorData {
  location: string
  device: string
  timeAgo: string
  page: string
}

export function VisitorAnalytics() {
  const [recentVisitors, setRecentVisitors] = useState<VisitorData[]>([])
  const [isVisible, setIsVisible] = useState(false)

  const locations = ["Delhi", "Mumbai", "Bangalore", "Gurgaon", "Noida", "Faridabad", "Pune", "Hyderabad"]
  const devices = ["Mobile", "Desktop", "Tablet"]
  const pages = ["Home", "Services", "Gallery", "Contact", "Venues", "About"]

  const generateRandomVisitor = (): VisitorData => ({
    location: locations[Math.floor(Math.random() * locations.length)],
    device: devices[Math.floor(Math.random() * devices.length)],
    timeAgo: `${Math.floor(Math.random() * 30) + 1} seconds ago`,
    page: pages[Math.floor(Math.random() * pages.length)],
  })

  useEffect(() => {
    // Initialize with some recent visitors
    const initialVisitors = Array.from({ length: 5 }, generateRandomVisitor)
    setRecentVisitors(initialVisitors)
    setIsVisible(true)

    // Add new visitors periodically
    const interval = setInterval(() => {
      if (Math.random() > 0.6) {
        // 40% chance to add a new visitor
        setRecentVisitors((prev) => {
          const newVisitor = generateRandomVisitor()
          return [newVisitor, ...prev.slice(0, 4)] // Keep only 5 most recent
        })
      }
    }, 5000) // Check every 5 seconds

    return () => clearInterval(interval)
  }, [])

  if (!isVisible) return null

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      transition={{ duration: 0.5 }}
      className="bg-white border-t border-gray-200 py-4"
    >
      <div className="container px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-gray-700">Recent Visitor Activity</span>
          </div>

          <div className="flex flex-wrap gap-2 max-w-2xl">
            {recentVisitors.map((visitor, index) => (
              <motion.div
                key={`${visitor.location}-${visitor.timeAgo}-${index}`}
                initial={{ opacity: 0, scale: 0.8, x: 20 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="bg-gray-50 rounded-full px-3 py-1 flex items-center space-x-2 text-xs"
              >
                <MapPin className="h-3 w-3 text-gray-500" />
                <span className="font-medium">{visitor.location}</span>
                <Badge variant="outline" className="text-xs px-1 py-0">
                  {visitor.device === "Mobile" ? <Smartphone className="h-2 w-2" /> : <Monitor className="h-2 w-2" />}
                </Badge>
                <span className="text-gray-500">•</span>
                <span className="text-gray-500">{visitor.page}</span>
                <Clock className="h-3 w-3 text-gray-400" />
                <span className="text-gray-400">{visitor.timeAgo}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  )
}
