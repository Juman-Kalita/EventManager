"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Award, Users, Clock, Star } from "lucide-react"

const features = [
  {
    icon: Award,
    title: "Award-Winning Service",
    description: "Recognized for excellence in event management and customer satisfaction.",
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Professional event planners with years of experience in the industry.",
  },
  {
    icon: Clock,
    title: "24/7 Support",
    description: "Round-the-clock assistance to ensure your event runs smoothly.",
  },
  {
    icon: Star,
    title: "Premium Quality",
    description: "We deliver exceptional quality in every aspect of your event.",
  },
]

export function AboutSection() {
  const scrollToContact = () => {
    const element = document.getElementById("contact")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="about" className="scroll-section py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Stellar Events</h2>
              <p className="mt-4 text-muted-foreground md:text-xl">
                With over a decade of experience in event management, we've built our reputation on creating
                extraordinary experiences that exceed expectations.
              </p>
            </div>
            <p className="text-muted-foreground">
              From intimate gatherings to grand celebrations, our team of dedicated professionals brings creativity,
              precision, and passion to every event. We understand that each occasion is unique, and we work closely
              with our clients to bring their vision to life.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" onClick={scrollToContact}>
                Start Planning Your Event
              </Button>
              <Button size="lg" variant="outline">
                View Our Portfolio
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-6"
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full tilt-effect">
                  <CardContent className="p-6">
                    <div className="rounded-full bg-primary/10 p-3 w-fit mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
