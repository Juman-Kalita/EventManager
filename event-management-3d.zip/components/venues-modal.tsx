"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Users, Star, Wifi, Car, Utensils, Music } from "lucide-react"
import { useState } from "react"
import { VenueBookingForm } from "@/components/venue-booking-form"

interface VenuesModalProps {
  isOpen: boolean
  onClose: () => void
}

const delhiVenues = [
  {
    id: 1,
    name: "The Imperial Hotel",
    location: "Janpath, Connaught Place",
    capacity: "500 guests",
    rating: 4.9,
    price: "₹2,50,000",
    image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=600&auto=format&fit=crop",
    description: "Luxury heritage hotel with grand ballrooms and impeccable service.",
    amenities: ["WiFi", "Parking", "Catering", "Sound System"],
    features: ["Heritage architecture", "Multiple event spaces", "5-star service", "Central location"],
  },
  {
    id: 2,
    name: "Taj Palace Hotel",
    location: "Diplomatic Enclave",
    capacity: "800 guests",
    rating: 4.8,
    price: "₹4,00,000",
    image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?q=80&w=600&auto=format&fit=crop",
    description: "Elegant venue with beautiful gardens and world-class facilities.",
    amenities: ["WiFi", "Parking", "Catering", "Sound System"],
    features: ["Garden venue", "Luxury amenities", "Professional staff", "Premium location"],
  },
  {
    id: 3,
    name: "India Habitat Centre",
    location: "Lodhi Road",
    capacity: "1000 guests",
    rating: 4.7,
    price: "₹1,80,000",
    image: "https://images.unsplash.com/photo-1511578314322-379afb476865?q=80&w=600&auto=format&fit=crop",
    description: "Modern convention center perfect for corporate events and conferences.",
    amenities: ["WiFi", "Parking", "Catering", "Sound System"],
    features: ["Modern facilities", "Multiple halls", "Tech-enabled", "Accessible location"],
  },
  {
    id: 4,
    name: "The Leela Palace",
    location: "Chanakyapuri",
    capacity: "600 guests",
    rating: 4.9,
    price: "₹5,00,000",
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=600&auto=format&fit=crop",
    description: "Opulent palace hotel with royal ambiance and exceptional hospitality.",
    amenities: ["WiFi", "Parking", "Catering", "Sound System"],
    features: ["Royal architecture", "Luxury interiors", "Premium service", "Exclusive venue"],
  },
  {
    id: 5,
    name: "Hyatt Regency Delhi",
    location: "Bhikaji Cama Place",
    capacity: "400 guests",
    rating: 4.6,
    price: "₹3,20,000",
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=600&auto=format&fit=crop",
    description: "Contemporary hotel with versatile event spaces and modern amenities.",
    amenities: ["WiFi", "Parking", "Catering", "Sound System"],
    features: ["Modern design", "Flexible spaces", "Business center", "Metro connectivity"],
  },
  {
    id: 6,
    name: "The Ashok Hotel",
    location: "Chanakyapuri",
    capacity: "700 guests",
    rating: 4.5,
    price: "₹2,80,000",
    image: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=600&auto=format&fit=crop",
    description: "Government-owned luxury hotel with spacious halls and traditional hospitality.",
    amenities: ["WiFi", "Parking", "Catering", "Sound System"],
    features: ["Spacious halls", "Traditional service", "Government rates", "Diplomatic area"],
  },
]

const amenityIcons = {
  WiFi: Wifi,
  Parking: Car,
  Catering: Utensils,
  "Sound System": Music,
}

export function VenuesModal({ isOpen, onClose }: VenuesModalProps) {
  const [selectedVenue, setSelectedVenue] = useState<(typeof delhiVenues)[0] | null>(null)
  const [showBookingForm, setShowBookingForm] = useState(false)

  const handleBookVenue = (venue: (typeof delhiVenues)[0]) => {
    setSelectedVenue(venue)
    setShowBookingForm(true)
  }

  const handleCloseBookingForm = () => {
    setShowBookingForm(false)
    setSelectedVenue(null)
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Premium Venues in Delhi</DialogTitle>
            <p className="text-muted-foreground">
              Discover our handpicked selection of the finest event venues across Delhi NCR
            </p>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {delhiVenues.map((venue) => (
              <Card key={venue.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={venue.image || "/placeholder.svg"}
                    alt={venue.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 rounded-full px-3 py-1 flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{venue.rating}</span>
                  </div>
                  <div className="absolute bottom-4 left-4 bg-black/70 text-white px-3 py-1 rounded-full">
                    <span className="text-sm font-bold">{venue.price}</span>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div>
                      <h3 className="text-lg font-bold">{venue.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        {venue.location}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Users className="h-4 w-4" />
                        Up to {venue.capacity}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{venue.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {venue.amenities.map((amenity) => {
                        const IconComponent = amenityIcons[amenity as keyof typeof amenityIcons]
                        return (
                          <div key={amenity} className="flex items-center gap-1 text-xs bg-muted px-2 py-1 rounded">
                            <IconComponent className="h-3 w-3" />
                            {amenity}
                          </div>
                        )
                      })}
                    </div>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {venue.features.slice(0, 3).map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <div className="w-1 h-1 bg-primary rounded-full" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full" onClick={() => handleBookVenue(venue)}>
                      Book This Venue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <VenueBookingForm isOpen={showBookingForm} onClose={handleCloseBookingForm} venue={selectedVenue} />
    </>
  )
}
