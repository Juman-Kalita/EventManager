"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, Phone, MessageCircle } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { WhatsAppButton } from "@/components/whatsapp-button"
import { Logo } from "@/components/logo"

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [activeSection, setActiveSection] = useState("hero")

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled)
      }

      // Determine active section based on scroll position
      const sections = ["hero", "about", "services", "venues", "gallery", "contact"]
      for (const section of sections.reverse()) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= 100) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [scrolled])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setActiveSection(sectionId)
    }
  }

  const handlePhoneCall = () => {
    window.open("tel:+919876543210", "_self")
  }

  const handleWhatsAppClick = () => {
    const whatsappUrl = `https://wa.me/919876543210?text=${encodeURIComponent(
      "Hello! I'm interested in your event management services in Delhi.",
    )}`
    window.open(whatsappUrl, "_blank")
  }

  const navItems = [
    { id: "hero", label: "HOME" },
    { id: "about", label: "ABOUT" },
    { id: "services", label: "SERVICES" },
    { id: "venues", label: "VENUES" },
    { id: "gallery", label: "GALLERY" },
    { id: "contact", label: "CONTACT US" },
  ]

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-white/95 backdrop-blur-md py-2 shadow-lg" : "bg-gradient-to-b from-black/50 to-transparent py-4"
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center">
          <Logo size={scrolled ? "sm" : "md"} />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center">
          <div className="bg-white/10 backdrop-blur-md rounded-full p-1 shadow-lg">
            <div className="flex items-center relative">
              <AnimatePresence>
                {navItems.map((item) => (
                  <div key={item.id} className="relative px-1">
                    <button
                      onClick={() => scrollToSection(item.id)}
                      className={`relative z-10 px-4 py-2 text-sm font-medium transition-colors rounded-full ${
                        activeSection === item.id
                          ? "text-white"
                          : scrolled
                            ? "text-gray-700 hover:text-primary"
                            : "text-white/90 hover:text-white"
                      }`}
                    >
                      {item.label}
                    </button>
                    {activeSection === item.id && (
                      <motion.div
                        layoutId="navIndicator"
                        className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                    )}
                  </div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </nav>

        <div className="hidden md:flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className={`rounded-full border-2 ${
              scrolled ? "border-primary/20 bg-white" : "border-white/30 bg-white/10 text-white hover:bg-white/20"
            }`}
            onClick={handlePhoneCall}
          >
            <Phone className="mr-2 h-4 w-4" />
            +91 98765 43210
          </Button>
          <Button
            variant="default"
            size="sm"
            className="rounded-full bg-green-500 hover:bg-green-600 shadow-md"
            onClick={handleWhatsAppClick}
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            WhatsApp
          </Button>
        </div>

        {/* Mobile Navigation */}
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className={`md:hidden rounded-full ${
                scrolled ? "bg-gray-100" : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <div className="flex items-center mb-8">
              <Logo size="md" />
            </div>
            <nav className="flex flex-col gap-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`flex items-center justify-between px-4 py-3 rounded-lg text-left font-medium transition-colors ${
                    activeSection === item.id
                      ? "bg-gradient-to-r from-purple-600/10 to-blue-600/10 text-primary"
                      : "hover:bg-gray-100"
                  }`}
                >
                  {item.label}
                  {activeSection === item.id && <div className="w-2 h-2 rounded-full bg-primary"></div>}
                </button>
              ))}
              <div className="flex flex-col gap-2 mt-6">
                <Button variant="outline" className="w-full justify-start" onClick={handlePhoneCall}>
                  <Phone className="mr-2 h-4 w-4" />
                  +91 98765 43210
                </Button>
                <WhatsAppButton phoneNumber="+919876543210" className="w-full justify-start" />
              </div>
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </motion.header>
  )
}
