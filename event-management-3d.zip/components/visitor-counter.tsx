"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Eye, Users, Globe, TrendingUp } from "lucide-react"

interface VisitorStats {
  currentVisitors: number
  totalVisitors: number
  todayVisitors: number
  monthlyVisitors: number
}

export function VisitorCounter() {
  const [stats, setStats] = useState<VisitorStats>({
    currentVisitors: 0,
    totalVisitors: 0,
    todayVisitors: 0,
    monthlyVisitors: 0,
  })

  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Initialize with base numbers
    const baseStats = {
      currentVisitors: Math.floor(Math.random() * 50) + 15, // 15-65 current visitors
      totalVisitors: Math.floor(Math.random() * 10000) + 45000, // 45k-55k total
      todayVisitors: Math.floor(Math.random() * 200) + 150, // 150-350 today
      monthlyVisitors: Math.floor(Math.random() * 5000) + 8000, // 8k-13k monthly
    }

    setStats(baseStats)
    setIsVisible(true)

    // Simulate real-time updates
    const interval = setInterval(() => {
      setStats((prev) => {
        const shouldUpdateCurrent = Math.random() > 0.7 // 30% chance to update
        const shouldUpdateToday = Math.random() > 0.9 // 10% chance to update
        const shouldUpdateTotal = Math.random() > 0.95 // 5% chance to update

        return {
          currentVisitors: shouldUpdateCurrent
            ? Math.max(1, prev.currentVisitors + (Math.random() > 0.5 ? 1 : -1))
            : prev.currentVisitors,
          totalVisitors: shouldUpdateTotal ? prev.totalVisitors + 1 : prev.totalVisitors,
          todayVisitors: shouldUpdateToday ? prev.todayVisitors + 1 : prev.todayVisitors,
          monthlyVisitors: prev.monthlyVisitors,
        }
      })
    }, 3000) // Update every 3 seconds

    return () => clearInterval(interval)
  }, [])

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M"
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K"
    }
    return num.toLocaleString()
  }

  const counterItems = [
    {
      icon: Eye,
      label: "Online Now",
      value: stats.currentVisitors,
      color: "text-green-500",
      bgColor: "bg-green-50",
      pulse: true,
    },
    {
      icon: Users,
      label: "Today's Visitors",
      value: stats.todayVisitors,
      color: "text-blue-500",
      bgColor: "bg-blue-50",
      pulse: false,
    },
    {
      icon: TrendingUp,
      label: "This Month",
      value: stats.monthlyVisitors,
      color: "text-purple-500",
      bgColor: "bg-purple-50",
      pulse: false,
    },
    {
      icon: Globe,
      label: "Total Visitors",
      value: stats.totalVisitors,
      color: "text-orange-500",
      bgColor: "bg-orange-50",
      pulse: false,
    },
  ]

  if (!isVisible) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-gradient-to-r from-gray-50 to-gray-100 border-t border-gray-200 py-6"
    >
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Live Website Statistics</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl">
            {counterItems.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-lg p-4 shadow-sm border border-gray-200 text-center"
              >
                <div className="flex flex-col items-center space-y-2">
                  <div className={`p-2 rounded-full ${item.bgColor} ${item.pulse ? "animate-pulse" : ""}`}>
                    <item.icon className={`h-5 w-5 ${item.color}`} />
                  </div>
                  <div className="space-y-1">
                    <motion.div
                      key={item.value}
                      initial={{ scale: 1.2, color: item.color.replace("text-", "#") }}
                      animate={{ scale: 1, color: "inherit" }}
                      transition={{ duration: 0.3 }}
                      className="text-2xl font-bold text-gray-900"
                    >
                      {formatNumber(item.value)}
                    </motion.div>
                    <div className="text-xs text-muted-foreground font-medium">{item.label}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="text-xs text-muted-foreground text-center">
            <p>Real-time visitor tracking • Updated every few seconds</p>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
